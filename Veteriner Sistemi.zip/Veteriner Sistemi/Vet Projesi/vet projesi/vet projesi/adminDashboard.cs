﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Mail;
using System.Data.SqlClient;

namespace vet_projesi
{
    public partial class adminDashboard : Form
    {
        public adminDashboard()
        {
            InitializeComponent();
        }


        int sayac = 0;

        Form1 form1 = new Form1();

        private void timerArama_Tick(object sender, EventArgs e)
        {
            sayac++;
            if (sayac == 20)
            {
                lblSonuc.Visible = false;
                sayac = 0;
            }
        }

        public void bilgileriGetir()
        {
            baglanti.Open();
            SqlCommand doldur = new SqlCommand("SELECT * FROM KullaniciBilgileri", baglanti);
            doldur.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(doldur);
            da.Fill(dt);
            dgwKullanicilar.DataSource = dt;
            baglanti.Close();
        }

        public void verileriGoster(string veriler)
        {
            SqlDataAdapter da = new SqlDataAdapter(veriler,baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dgwKullanicilar.DataSource = ds.Tables[0];
        }

        
        SqlConnection baglanti = new SqlConnection("Server = LAPTOP-QLN317KI\\SQLEXPRESS ; Initial Catalog = HastaKayitVeteriner ; Integrated Security = True");
        
        private void btnGonder_Click(object sender, EventArgs e)
        {
            if (txtEposta.Text.Length < 15)
            {
                MessageBox.Show("Geçerli Bir Eposta Adresi Giriniz.","Uyarı",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
            else if (txtMetin.Text.Length == 0)
            {
                MessageBox.Show("Metin İçeriğiniz Boş Olamaz", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                MailMessage mesajim = new MailMessage();
                SmtpClient istemci = new SmtpClient();
                istemci.Credentials = new System.Net.NetworkCredential("yusufcakmak29@gmail.com", "281200yusuf");//Deneme olarak açtığım e-posta adresidir.
                istemci.Host = "smtp.live.com";
                istemci.Port = 587;
                istemci.EnableSsl = true;
                mesajim.To.Add(txtEposta.Text);
                mesajim.From = new MailAddress("yusufcakmak29@gmail.com");
                mesajim.Subject = "Bilgilendirme Mesajı";
                mesajim.Body = txtMetin.Text;
                istemci.Send(mesajim);
                MessageBox.Show("İşlem Başarılı");
            }
            }
        private void adminDashboard_Load(object sender, EventArgs e)
        {
            timerTarihSaat.Start();
            verileriGoster("SELECT * FROM KullaniciBilgileri");

            baglanti.Open();
            SqlCommand getir = new SqlCommand("SELECT count(kullanici_id) FROM KullaniciBilgileri", baglanti);
            lblToplamUye.Text = getir.ExecuteScalar().ToString();

            baglanti.Close();
        }

        private void btnKucult_Click(object sender, EventArgs e)
        {
            Font eski = txtMetin.Font;
            txtMetin.Font = new Font(eski.FontFamily, eski.Size - 2, eski.Style);
            
        }

        private void btnArttir_Click(object sender, EventArgs e)
        {
            Font eski = txtMetin.Font;
            txtMetin.Font = new Font(eski.FontFamily, eski.Size + 2, eski.Style);
        }

        private void btnKalin_Click(object sender, EventArgs e)
        {
            txtMetin.Font = new Font(txtMetin.Font, txtMetin.Font.Style ^ FontStyle.Bold);
        }

        private void btnAltiCizili_Click(object sender, EventArgs e)
        {
            txtMetin.Font = new Font(txtMetin.Font, txtMetin.Font.Style ^ FontStyle.Underline);
        }

        

        private void btnKullaniciBul_Click(object sender, EventArgs e)
        {
            if (txtKullaniciAra.Text.Length <= 0)
            {
                MessageBox.Show("Arama Kutucuğunu Boş Bırakmayınız.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                baglanti.Open();
                SqlCommand sorgu = new SqlCommand("SELECT * FROM KullaniciBilgileri WHERE adi like '%" + txtKullaniciAra.Text + "%'", baglanti);
                sorgu.ExecuteReader();
                lblSonuc.Visible = true;
                timerArama.Start();
                baglanti.Close();
                
            }
        }

        private void kayitSil()
        {
            baglanti.Open();
            SqlCommand sorgu = new SqlCommand("DELETE FROM KullaniciBilgileri WHERE kullanici_id='" + txtIdleriTasi.Text + "'", baglanti); //Mouse ile seçtiğimiz sütuna göre silme yapacak
            sorgu.ExecuteNonQuery();
            baglanti.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Seçilen kullanıcıyı Silmek İstiyor Musunuz?","Uyarı",MessageBoxButtons.YesNo,MessageBoxIcon.Information);
            if(dr == DialogResult.Yes)
            {
                kayitSil();
                MessageBox.Show("Kullanıcı Başarıyla Silindi.", "Uyarı", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                verileriGoster("SELECT * FROM KullaniciBilgileri");
            }
        }

       private void engelle()
        {
            baglanti.Open();
            SqlCommand sorgu = new SqlCommand("UPDATE KullaniciBilgileri SET is_banned='T' WHERE is_banned='F' AND kullanici_id ='" + txtIdleriTasi.Text + "'", baglanti); //Mouse ile seçtiğimiz sütundaki kişiyi banlar
            sorgu.ExecuteNonQuery();
            baglanti.Close();
            
        }
        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Seçilen kullanıcıyı Engellemek İstiyor Musunuz?", "Uyarı", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dr == DialogResult.Yes)
            {
                engelle();
                MessageBox.Show("Kullanıcı Başarıyla Engellendi.", "Uyarı", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                verileriGoster("SELECT * FROM KullaniciBilgileri");
            }
        }
        private void engeliKaldir()
        {
            baglanti.Open();
            SqlCommand sorgu = new SqlCommand("UPDATE KullaniciBilgileri SET is_banned='F' WHERE is_banned='T' AND kullanici_id ='" + txtIdleriTasi.Text + "'", baglanti); //Mouse ile seçtiğimiz sütundaki kişinin banını kaldıracak
            sorgu.ExecuteNonQuery();
            baglanti.Close();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Seçilen kullanıcının Engelini Kaldırmak İstiyor Musunuz?", "Uyarı", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dr == DialogResult.Yes)
            {
                engeliKaldir();
                MessageBox.Show("Kullanıcının Engeli Başarıyla Kaldırıldı", "Uyarı", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                verileriGoster("SELECT * FROM KullaniciBilgileri");
            }
        }

        private void timerTarihSaat_Tick(object sender, EventArgs e)
        {
            DateTime dateSaat = DateTime.Now;
            lblSaat.Text = dateSaat.ToLongTimeString();
            lblTarih.Text = dateSaat.ToLongDateString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Çıkış Yapmak İstediğinizden Emin Misinz?", "Uyarı", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if(dr == DialogResult.Yes)
            {
                form1.Show();
                this.Hide();
            }
        }


        private void btnKirmizi_Click(object sender, EventArgs e)
        {
            txtMetin.ForeColor = Color.Red;
        }

        private void btnYesil_Click(object sender, EventArgs e)
        {
            txtMetin.ForeColor = Color.Green;
        }

        private void btnMavi_Click(object sender, EventArgs e)
        {
            txtMetin.ForeColor = Color.Blue;
        }

        private void btnPembe_Click(object sender, EventArgs e)
        {
            txtMetin.ForeColor = Color.Purple;
        }

        private void btnSiyah_Click(object sender, EventArgs e)
        {
            txtMetin.ForeColor = Color.Black;
        }

        private void btnAltSatiraGec_Click(object sender, EventArgs e)
        {
            txtMetin.Text += "\n";
        }


        private void button5_Click(object sender, EventArgs e)
        {
            verileriGoster("SELECT * FROM KullaniciBilgileri");
        }

        private void txtKullaniciAra_TextChanged(object sender, EventArgs e)
        {
            baglanti.Open();
            DataTable dt = new DataTable();
            SqlDataAdapter ara = new SqlDataAdapter("SELECT * FROM KullaniciBilgileri WHERE adi LIKE '%" + txtKullaniciAra.Text + "%'", baglanti);
            ara.Fill(dt);
            baglanti.Close();
            dgwKullanicilar.DataSource = dt;
        }

        private void dgwKullanicilar_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtIdleriTasi.Text = dgwKullanicilar.CurrentRow.Cells[0].Value.ToString();
        }

    }
}
