﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace vet_projesi
{
    public partial class adminGiris : Form
    {
        public adminGiris()
        {
            InitializeComponent();
        }

        SqlConnection baglanti = new SqlConnection("Server = LAPTOP-QLN317KI\\SQLEXPRESS ; Initial Catalog = HastaKayitVeteriner ; Integrated Security = True");

        adminDashboard ad = new adminDashboard();

        private void button1_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            SqlCommand getir = new SqlCommand("SELECT * FROM admin WHERE kullanici_adi = @kullaniciAdi AND sifre = @sifre AND is_banned ='F'", baglanti);
            getir.Parameters.AddWithValue("@kullaniciAdi", txtKullaniciAdiAdmin.Text);
            getir.Parameters.AddWithValue("@sifre", txtSifreAdmin.Text);
            SqlDataReader dr = getir.ExecuteReader();
            if (dr.Read())
            {
                MessageBox.Show("Başarıyla Giriş Yaptınız.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ad.lblAdAdmin.Text = txtKullaniciAdiAdmin.Text;
                this.Hide();
                ad.Show();
            }
            else
            {
                
                MessageBox.Show("Kullanıcı Bilgileriniz Hatalı Ya da Hesabınız Kapalı.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            baglanti.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            this.Hide();

            form1.Show();
        }

    }
}
