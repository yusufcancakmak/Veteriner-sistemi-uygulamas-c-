﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace vet_projesi
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        SqlConnection baglanti = new SqlConnection("Server = LAPTOP-QLN317KI\\SQLEXPRESS ; Initial Catalog = HastaKayitVeteriner; Integrated Security = True");

        private void btnCikisYap_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Çıkış Yapmak İstediğinize Emin Misiniz?","◑﹏◐",MessageBoxButtons.YesNo,MessageBoxIcon.Information);
            if(dialogResult == DialogResult.Yes)
            {
                Form1 form1 = new Form1();
                this.Hide();
                form1.Show();
            }
        }


        private void timerTarihSaat_Tick(object sender, EventArgs e)
        {
            DateTime dateSaat = DateTime.Now;
            lblSaat.Text = dateSaat.ToLongTimeString();
            lblTarih.Text = dateSaat.ToLongDateString();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            timerTarihSaat.Start();
        }

        private void txtNotEkle_Click(object sender, EventArgs e)
        {
            if(txtNotEkle.Text == "Maksimum 100 Karakter Giriniz")
            {
                txtNotEkle.Text = "";
                txtNotEkle.ForeColor = Color.Black;
            }
        }

        private void btnProfil_Click(object sender, EventArgs e)
        {
            Profilim profilim = new Profilim();
            profilim.txtAdi.Text = lblAd.Text;
            profilim.lblAdTasi.Text = lblAd.Text;
            profilim.Show();
            this.Hide();
        }

        private void btnRandevuAl_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show(dtpRandevuAl.Value.ToShortDateString() + "\nBu tarihte randevu almak istediğinize emin misiniz?","Bilgi",MessageBoxButtons.YesNo,MessageBoxIcon.Information);
            if(dr == DialogResult.Yes)
            {
                try
                {
                    if (baglanti.State == ConnectionState.Closed)
                    {
                        MessageBox.Show("Hasta Adı : " + txtHastaAdi.Text + "\n" + "Hayvanın Cinsi : " + txtCinsi.Text + "\n" + "Hayvanın Türü : " + txtTuru.Text + "\n" + "Eklemek İstediğiniz Not : " + txtNotEkle.Text + "\n" + "Randevu Tarihi : " + dtpRandevuAl.Value.ToShortDateString(), "Bilgilerinizi Not Alınız.");
                        baglanti.Open();
                        SqlCommand ekle = new SqlCommand("INSERT INTO randevular (hasta_adi,turu,cinsi,randevu_tarihi,not_ekle) VALUES (@hasta_adi,@turu,@cinsi,@randevu_tarihi,@not_ekle)", baglanti);
                        ekle.Parameters.AddWithValue("@hasta_adi", txtHastaAdi.Text);
                        ekle.Parameters.AddWithValue("@turu", txtTuru.Text);
                        ekle.Parameters.AddWithValue("@cinsi", txtCinsi.Text);
                        ekle.Parameters.AddWithValue("@randevu_tarihi", dtpRandevuAl.Value.ToShortDateString());
                        ekle.Parameters.AddWithValue("@not_ekle", txtNotEkle.Text);
                        ekle.ExecuteNonQuery();
                        MessageBox.Show("Randevunuz Başarıyla Alınmıştır.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        baglanti.Close();
                    }
                }
                catch(Exception ex)
                {
                    MessageBox.Show("İşlem Sırasında Hata Oluştu." + ex.Message);
                }
            }
        }
    }
}
