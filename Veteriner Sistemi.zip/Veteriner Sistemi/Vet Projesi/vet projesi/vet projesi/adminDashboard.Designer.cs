﻿namespace vet_projesi
{
    partial class adminDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(adminDashboard));
            this.label1 = new System.Windows.Forms.Label();
            this.lblToplamUye = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtMetin = new System.Windows.Forms.TextBox();
            this.btnGonder = new System.Windows.Forms.Button();
            this.txtEposta = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtIdleriTasi = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.btnAltSatiraGec = new System.Windows.Forms.Button();
            this.btnSiyah = new System.Windows.Forms.Button();
            this.btnPembe = new System.Windows.Forms.Button();
            this.btnYesil = new System.Windows.Forms.Button();
            this.btnMavi = new System.Windows.Forms.Button();
            this.btnKirmizi = new System.Windows.Forms.Button();
            this.lblSonuc = new System.Windows.Forms.Label();
            this.btnKullaniciBul = new System.Windows.Forms.Button();
            this.txtKullaniciAra = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblKullaniciAdi = new System.Windows.Forms.Label();
            this.dgwKullanicilar = new System.Windows.Forms.DataGridView();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnAltiCizili = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btnKalin = new System.Windows.Forms.Button();
            this.btnArttir = new System.Windows.Forms.Button();
            this.btnKucult = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.timerArama = new System.Windows.Forms.Timer(this.components);
            this.timerTarihSaat = new System.Windows.Forms.Timer(this.components);
            this.lblTarih = new System.Windows.Forms.Label();
            this.lblSaat = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblAdAdmin = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgwKullanicilar)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(886, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(263, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Toplam Kullanıcı Sayısı";
            // 
            // lblToplamUye
            // 
            this.lblToplamUye.AutoSize = true;
            this.lblToplamUye.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.lblToplamUye.ForeColor = System.Drawing.Color.White;
            this.lblToplamUye.Location = new System.Drawing.Point(1167, 27);
            this.lblToplamUye.Name = "lblToplamUye";
            this.lblToplamUye.Size = new System.Drawing.Size(79, 29);
            this.lblToplamUye.TabIndex = 1;
            this.lblToplamUye.Text = "label2";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(211, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(312, 36);
            this.label2.TabIndex = 2;
            this.label2.Text = "Üyelere Mail Gönderin";
            // 
            // txtMetin
            // 
            this.txtMetin.BackColor = System.Drawing.Color.White;
            this.txtMetin.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtMetin.Location = new System.Drawing.Point(133, 197);
            this.txtMetin.Multiline = true;
            this.txtMetin.Name = "txtMetin";
            this.txtMetin.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtMetin.Size = new System.Drawing.Size(585, 217);
            this.txtMetin.TabIndex = 3;
            // 
            // btnGonder
            // 
            this.btnGonder.BackColor = System.Drawing.Color.LightSeaGreen;
            this.btnGonder.FlatAppearance.BorderSize = 0;
            this.btnGonder.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGonder.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnGonder.ForeColor = System.Drawing.Color.White;
            this.btnGonder.Location = new System.Drawing.Point(197, 573);
            this.btnGonder.Name = "btnGonder";
            this.btnGonder.Size = new System.Drawing.Size(444, 48);
            this.btnGonder.TabIndex = 5;
            this.btnGonder.Text = "Gönder";
            this.btnGonder.UseVisualStyleBackColor = false;
            this.btnGonder.Click += new System.EventHandler(this.btnGonder_Click);
            // 
            // txtEposta
            // 
            this.txtEposta.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtEposta.Location = new System.Drawing.Point(133, 123);
            this.txtEposta.Name = "txtEposta";
            this.txtEposta.Size = new System.Drawing.Size(346, 34);
            this.txtEposta.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(24, 123);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 29);
            this.label3.TabIndex = 7;
            this.label3.Text = "Eposta";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.txtIdleriTasi);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.btnAltSatiraGec);
            this.panel1.Controls.Add(this.btnSiyah);
            this.panel1.Controls.Add(this.btnPembe);
            this.panel1.Controls.Add(this.btnYesil);
            this.panel1.Controls.Add(this.btnMavi);
            this.panel1.Controls.Add(this.btnKirmizi);
            this.panel1.Controls.Add(this.lblSonuc);
            this.panel1.Controls.Add(this.btnKullaniciBul);
            this.panel1.Controls.Add(this.txtKullaniciAra);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.lblKullaniciAdi);
            this.panel1.Controls.Add(this.dgwKullanicilar);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.btnAltiCizili);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.btnKalin);
            this.panel1.Controls.Add(this.btnArttir);
            this.panel1.Controls.Add(this.btnKucult);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.txtEposta);
            this.panel1.Controls.Add(this.btnGonder);
            this.panel1.Controls.Add(this.txtMetin);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(0, 86);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1788, 650);
            this.panel1.TabIndex = 8;
            // 
            // txtIdleriTasi
            // 
            this.txtIdleriTasi.Location = new System.Drawing.Point(1564, 3);
            this.txtIdleriTasi.Name = "txtIdleriTasi";
            this.txtIdleriTasi.Size = new System.Drawing.Size(285, 22);
            this.txtIdleriTasi.TabIndex = 19;
            this.txtIdleriTasi.Visible = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.LightSeaGreen;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(1172, 573);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(299, 47);
            this.button5.TabIndex = 26;
            this.button5.Text = "Hepsini Getir";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // btnAltSatiraGec
            // 
            this.btnAltSatiraGec.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnAltSatiraGec.Location = new System.Drawing.Point(561, 459);
            this.btnAltSatiraGec.Name = "btnAltSatiraGec";
            this.btnAltSatiraGec.Size = new System.Drawing.Size(80, 33);
            this.btnAltSatiraGec.TabIndex = 25;
            this.btnAltSatiraGec.Text = "/";
            this.btnAltSatiraGec.UseVisualStyleBackColor = true;
            this.btnAltSatiraGec.Click += new System.EventHandler(this.btnAltSatiraGec_Click);
            // 
            // btnSiyah
            // 
            this.btnSiyah.BackColor = System.Drawing.Color.Black;
            this.btnSiyah.FlatAppearance.BorderSize = 0;
            this.btnSiyah.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSiyah.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnSiyah.Location = new System.Drawing.Point(508, 427);
            this.btnSiyah.Name = "btnSiyah";
            this.btnSiyah.Size = new System.Drawing.Size(44, 18);
            this.btnSiyah.TabIndex = 24;
            this.btnSiyah.UseVisualStyleBackColor = false;
            this.btnSiyah.Click += new System.EventHandler(this.btnSiyah_Click);
            // 
            // btnPembe
            // 
            this.btnPembe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnPembe.FlatAppearance.BorderSize = 0;
            this.btnPembe.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPembe.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnPembe.Location = new System.Drawing.Point(458, 427);
            this.btnPembe.Name = "btnPembe";
            this.btnPembe.Size = new System.Drawing.Size(44, 18);
            this.btnPembe.TabIndex = 23;
            this.btnPembe.UseVisualStyleBackColor = false;
            this.btnPembe.Click += new System.EventHandler(this.btnPembe_Click);
            // 
            // btnYesil
            // 
            this.btnYesil.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnYesil.FlatAppearance.BorderSize = 0;
            this.btnYesil.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnYesil.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnYesil.Location = new System.Drawing.Point(358, 427);
            this.btnYesil.Name = "btnYesil";
            this.btnYesil.Size = new System.Drawing.Size(44, 18);
            this.btnYesil.TabIndex = 22;
            this.btnYesil.UseVisualStyleBackColor = false;
            this.btnYesil.Click += new System.EventHandler(this.btnYesil_Click);
            // 
            // btnMavi
            // 
            this.btnMavi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnMavi.FlatAppearance.BorderSize = 0;
            this.btnMavi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMavi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnMavi.Location = new System.Drawing.Point(408, 427);
            this.btnMavi.Name = "btnMavi";
            this.btnMavi.Size = new System.Drawing.Size(44, 18);
            this.btnMavi.TabIndex = 21;
            this.btnMavi.UseVisualStyleBackColor = false;
            this.btnMavi.Click += new System.EventHandler(this.btnMavi_Click);
            // 
            // btnKirmizi
            // 
            this.btnKirmizi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnKirmizi.FlatAppearance.BorderSize = 0;
            this.btnKirmizi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnKirmizi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKirmizi.Location = new System.Drawing.Point(308, 427);
            this.btnKirmizi.Name = "btnKirmizi";
            this.btnKirmizi.Size = new System.Drawing.Size(44, 18);
            this.btnKirmizi.TabIndex = 20;
            this.btnKirmizi.UseVisualStyleBackColor = false;
            this.btnKirmizi.Click += new System.EventHandler(this.btnKirmizi_Click);
            // 
            // lblSonuc
            // 
            this.lblSonuc.AutoSize = true;
            this.lblSonuc.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblSonuc.ForeColor = System.Drawing.Color.DarkOrchid;
            this.lblSonuc.Location = new System.Drawing.Point(980, 528);
            this.lblSonuc.Name = "lblSonuc";
            this.lblSonuc.Size = new System.Drawing.Size(344, 29);
            this.lblSonuc.TabIndex = 19;
            this.lblSonuc.Text = "Aramanız Başarıyla Gerçekleşti";
            this.lblSonuc.Visible = false;
            // 
            // btnKullaniciBul
            // 
            this.btnKullaniciBul.BackColor = System.Drawing.Color.LightSeaGreen;
            this.btnKullaniciBul.FlatAppearance.BorderSize = 0;
            this.btnKullaniciBul.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnKullaniciBul.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKullaniciBul.ForeColor = System.Drawing.Color.White;
            this.btnKullaniciBul.Location = new System.Drawing.Point(838, 573);
            this.btnKullaniciBul.Name = "btnKullaniciBul";
            this.btnKullaniciBul.Size = new System.Drawing.Size(299, 47);
            this.btnKullaniciBul.TabIndex = 17;
            this.btnKullaniciBul.Text = "Kullanıcıyı Bul";
            this.btnKullaniciBul.UseVisualStyleBackColor = false;
            this.btnKullaniciBul.Click += new System.EventHandler(this.btnKullaniciBul_Click);
            // 
            // txtKullaniciAra
            // 
            this.txtKullaniciAra.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtKullaniciAra.Location = new System.Drawing.Point(1120, 486);
            this.txtKullaniciAra.Name = "txtKullaniciAra";
            this.txtKullaniciAra.Size = new System.Drawing.Size(219, 30);
            this.txtKullaniciAra.TabIndex = 16;
            this.txtKullaniciAra.TextChanged += new System.EventHandler(this.txtKullaniciAra_TextChanged);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel2.Location = new System.Drawing.Point(757, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(10, 666);
            this.panel2.TabIndex = 14;
            // 
            // lblKullaniciAdi
            // 
            this.lblKullaniciAdi.AutoSize = true;
            this.lblKullaniciAdi.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblKullaniciAdi.Location = new System.Drawing.Point(968, 486);
            this.lblKullaniciAdi.Name = "lblKullaniciAdi";
            this.lblKullaniciAdi.Size = new System.Drawing.Size(145, 29);
            this.lblKullaniciAdi.TabIndex = 15;
            this.lblKullaniciAdi.Text = "Kullanıcı Adı";
            // 
            // dgwKullanicilar
            // 
            this.dgwKullanicilar.AllowUserToAddRows = false;
            this.dgwKullanicilar.AllowUserToDeleteRows = false;
            this.dgwKullanicilar.AllowUserToResizeColumns = false;
            this.dgwKullanicilar.AllowUserToResizeRows = false;
            this.dgwKullanicilar.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgwKullanicilar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgwKullanicilar.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgwKullanicilar.DefaultCellStyle = dataGridViewCellStyle4;
            this.dgwKullanicilar.Location = new System.Drawing.Point(791, 77);
            this.dgwKullanicilar.Name = "dgwKullanicilar";
            this.dgwKullanicilar.ReadOnly = true;
            this.dgwKullanicilar.RowHeadersWidth = 4;
            this.dgwKullanicilar.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgwKullanicilar.RowTemplate.Height = 24;
            this.dgwKullanicilar.Size = new System.Drawing.Size(734, 392);
            this.dgwKullanicilar.TabIndex = 14;
            this.dgwKullanicilar.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgwKullanicilar_CellClick);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.LightSeaGreen;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(1285, 31);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(240, 40);
            this.button3.TabIndex = 13;
            this.button3.Text = "Engeli Kaldır";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.LightSeaGreen;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(791, 31);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(238, 41);
            this.button1.TabIndex = 11;
            this.button1.Text = "Kullanıcıyı Engelle";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnAltiCizili
            // 
            this.btnAltiCizili.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnAltiCizili.Location = new System.Drawing.Point(647, 420);
            this.btnAltiCizili.Name = "btnAltiCizili";
            this.btnAltiCizili.Size = new System.Drawing.Size(80, 33);
            this.btnAltiCizili.TabIndex = 12;
            this.btnAltiCizili.Text = "A";
            this.btnAltiCizili.UseVisualStyleBackColor = true;
            this.btnAltiCizili.Click += new System.EventHandler(this.btnAltiCizili_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.LightSeaGreen;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(1037, 31);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(238, 40);
            this.button2.TabIndex = 10;
            this.button2.Text = "Kullanıcıyı Sil";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnKalin
            // 
            this.btnKalin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKalin.Location = new System.Drawing.Point(561, 420);
            this.btnKalin.Name = "btnKalin";
            this.btnKalin.Size = new System.Drawing.Size(80, 33);
            this.btnKalin.TabIndex = 11;
            this.btnKalin.Text = "K";
            this.btnKalin.UseVisualStyleBackColor = true;
            this.btnKalin.Click += new System.EventHandler(this.btnKalin_Click);
            // 
            // btnArttir
            // 
            this.btnArttir.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnArttir.Location = new System.Drawing.Point(217, 420);
            this.btnArttir.Name = "btnArttir";
            this.btnArttir.Size = new System.Drawing.Size(80, 33);
            this.btnArttir.TabIndex = 10;
            this.btnArttir.Text = "+";
            this.btnArttir.UseVisualStyleBackColor = true;
            this.btnArttir.Click += new System.EventHandler(this.btnArttir_Click);
            // 
            // btnKucult
            // 
            this.btnKucult.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKucult.Location = new System.Drawing.Point(133, 420);
            this.btnKucult.Name = "btnKucult";
            this.btnKucult.Size = new System.Drawing.Size(80, 33);
            this.btnKucult.TabIndex = 9;
            this.btnKucult.Text = "-";
            this.btnKucult.UseVisualStyleBackColor = true;
            this.btnKucult.Click += new System.EventHandler(this.btnKucult_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(14, 269);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(113, 58);
            this.label4.TabIndex = 8;
            this.label4.Text = "    Mail \r\nDetayları:";
            // 
            // timerArama
            // 
            this.timerArama.Tick += new System.EventHandler(this.timerArama_Tick);
            // 
            // timerTarihSaat
            // 
            this.timerTarihSaat.Tick += new System.EventHandler(this.timerTarihSaat_Tick);
            // 
            // lblTarih
            // 
            this.lblTarih.AutoSize = true;
            this.lblTarih.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTarih.ForeColor = System.Drawing.Color.White;
            this.lblTarih.Location = new System.Drawing.Point(556, 749);
            this.lblTarih.Name = "lblTarih";
            this.lblTarih.Size = new System.Drawing.Size(87, 29);
            this.lblTarih.TabIndex = 10;
            this.lblTarih.Text = "Tarih : ";
            // 
            // lblSaat
            // 
            this.lblSaat.AutoSize = true;
            this.lblSaat.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblSaat.ForeColor = System.Drawing.Color.White;
            this.lblSaat.Location = new System.Drawing.Point(860, 749);
            this.lblSaat.Name = "lblSaat";
            this.lblSaat.Size = new System.Drawing.Size(79, 29);
            this.lblSaat.TabIndex = 11;
            this.lblSaat.Text = "Saat : ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F);
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(832, 746);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(22, 32);
            this.label6.TabIndex = 12;
            this.label6.Text = "|";
            // 
            // lblAdAdmin
            // 
            this.lblAdAdmin.AutoSize = true;
            this.lblAdAdmin.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblAdAdmin.ForeColor = System.Drawing.Color.White;
            this.lblAdAdmin.Location = new System.Drawing.Point(1390, 9);
            this.lblAdAdmin.Name = "lblAdAdmin";
            this.lblAdAdmin.Size = new System.Drawing.Size(81, 29);
            this.lblAdAdmin.TabIndex = 15;
            this.lblAdAdmin.Text = "Admin";
            // 
            // button4
            // 
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Image = ((System.Drawing.Image)(resources.GetObject("button4.Image")));
            this.button4.Location = new System.Drawing.Point(1418, 41);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(37, 37);
            this.button4.TabIndex = 16;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(39, 20);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(345, 38);
            this.label8.TabIndex = 17;
            this.label8.Text = "Panel Yönetim Sayfası";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(1143, 22);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(24, 36);
            this.label9.TabIndex = 18;
            this.label9.Text = ":";
            // 
            // adminDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScrollMargin = new System.Drawing.Size(15, 100);
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(1561, 796);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.lblAdAdmin);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lblSaat);
            this.Controls.Add(this.lblTarih);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblToplamUye);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.Name = "adminDashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "adminGiris";
            this.Load += new System.EventHandler(this.adminDashboard_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgwKullanicilar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblToplamUye;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtMetin;
        private System.Windows.Forms.Button btnGonder;
        private System.Windows.Forms.TextBox txtEposta;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnArttir;
        private System.Windows.Forms.Button btnKucult;
        private System.Windows.Forms.Button btnKalin;
        private System.Windows.Forms.Button btnAltiCizili;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dgwKullanicilar;
        private System.Windows.Forms.Label lblKullaniciAdi;
        private System.Windows.Forms.TextBox txtKullaniciAra;
        private System.Windows.Forms.Button btnKullaniciBul;
        private System.Windows.Forms.Label lblSonuc;
        private System.Windows.Forms.Timer timerArama;
        private System.Windows.Forms.Timer timerTarihSaat;
        private System.Windows.Forms.Label lblTarih;
        private System.Windows.Forms.Label lblSaat;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnSiyah;
        private System.Windows.Forms.Button btnPembe;
        private System.Windows.Forms.Button btnYesil;
        private System.Windows.Forms.Button btnMavi;
        private System.Windows.Forms.Button btnKirmizi;
        private System.Windows.Forms.Button btnAltSatiraGec;
        public System.Windows.Forms.Label lblAdAdmin;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox txtIdleriTasi;
    }
}