﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace vet_projesi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public SqlConnection baglanti = new SqlConnection("Server = LAPTOP-QLN317KI\\SQLEXPRESS ; Initial Catalog = HastaKayitVeteriner ; Integrated Security = True");
        Form2 form2 = new Form2();
        int sayac = 0;


        private void timerHata_Tick(object sender, EventArgs e)
        {
            sayac++;
            if (sayac == 20)
            {
                lblHata.Visible = false;
                sayac = 0;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            SqlCommand sorgu = new SqlCommand("SELECT * FROM KullaniciBilgileri WHERE adi = @Adi AND sifre = @Sifre AND is_banned ='F'", baglanti);
            sorgu.Parameters.AddWithValue("@Adi", alphaBlendTextBox1.Text);
            sorgu.Parameters.AddWithValue("@Sifre", alphaBlendTextBox2.Text);
            SqlDataReader dr = sorgu.ExecuteReader();
            if (dr.Read())
            {
                MessageBox.Show("Başarıyla Giriş Yaptınız.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Information);

                form2.lblAd.Text = alphaBlendTextBox1.Text;
                this.Hide();
                form2.Show();
            }
            else
            {
                timerHata.Start();
                lblHata.Visible = true;
            }

            baglanti.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            uyeOl uyeOl = new uyeOl();
            this.Hide();
            uyeOl.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.SetStyle(ControlStyles.SupportsTransparentBackColor, true);
            this.BackColor = System.Drawing.Color.Transparent;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            adminGiris ag = new adminGiris();
            ag.Show();
            this.Hide();
        }




        private void txtparola_MouseClick(object sender, MouseEventArgs e)
        {
            panel1.BackColor = System.Drawing.Color.Silver;
            if (panel1.BackColor == System.Drawing.Color.Orange)
            {
                panel4.BackColor = System.Drawing.Color.Silver;
            }
        }

        private void alphaBlendTextBox1_Click(object sender, EventArgs e)
        {
            panel1.BackColor = System.Drawing.Color.Orange;
        }

        private void alphaBlendTextBox2_Click(object sender, EventArgs e)
        {
            panel4.BackColor = System.Drawing.Color.Orange;
            if (panel1.BackColor == System.Drawing.Color.Black)
            {
                panel1.BackColor = System.Drawing.Color.Orange;
            }
        }

        private void alphaBlendTextBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button1.PerformClick();
            }
        }

        private void alphaBlendTextBox2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button1.PerformClick();
            }
        }

      

        private void alphaBlendTextBox1_MouseClick(object sender, MouseEventArgs e)
        {
            panel1.BackColor = System.Drawing.Color.Orange;
        }

        private void alphaBlendTextBox2_KeyDown_1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button1.PerformClick();
            }
        }
    }
}

