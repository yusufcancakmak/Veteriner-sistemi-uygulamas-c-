﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace vet_projesi
{
    public partial class Profilim : Form
    {
        public Profilim()
        {
            InitializeComponent();
        }

        public SqlConnection baglanti = new SqlConnection("Server = LAPTOP-QLN317KI\\SQLEXPRESS ; Initial Catalog = HastaKayitVeteriner ; Integrated Security = True");

        private void Profilim_Load(object sender, EventArgs e)
        {
            baglanti.Open();

            SqlCommand sorgu = new SqlCommand("SELECT adi,soyadi,sifre,telefon_no FROM KullaniciBilgileri WHERE adi=@adi", baglanti);
            sorgu.Parameters.AddWithValue("@adi",lblAdTasi.Text);
            SqlDataReader dr = sorgu.ExecuteReader();
            if (dr.Read())
            {
                txtSoyadi.Text = dr["soyadi"].ToString();
                txtSifre.Text = dr["sifre"].ToString();
                mskTelefonNo.Text = dr["telefon_no"].ToString();
            }
            else
            {

            }
            baglanti.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.lblAd.Text = txtAdi.Text;
            this.Hide();
            form2.Show();
        }

        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            //Bu button kullanılmayacak.
            baglanti.Open();
            SqlCommand guncelle = new SqlCommand("UPDATE KullaniciBilgileri SET adi=@adi,soyadi=@soyadi,sifre=@sifre,telefon_no=@telefon WHERE adi = '" + lblAdTasi.Text + "'", baglanti);
            guncelle.Parameters.AddWithValue("@adi", txtAdi.Text);
            guncelle.Parameters.AddWithValue("@soyadi", txtSoyadi.Text);
            guncelle.Parameters.AddWithValue("@sifre", txtSifre.Text);
            guncelle.Parameters.AddWithValue("@telefon", mskTelefonNo.Text);
            guncelle.ExecuteNonQuery();
            MessageBox.Show("Hesabınız Başarıyla Güncellendi.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
            baglanti.Close();
        }
    }
}
