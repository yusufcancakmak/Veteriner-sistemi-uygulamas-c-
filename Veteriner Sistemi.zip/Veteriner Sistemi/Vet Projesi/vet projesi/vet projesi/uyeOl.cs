﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace vet_projesi
{
    public partial class uyeOl : Form
    {
        public uyeOl()
        {
            InitializeComponent();
        }

        public SqlConnection baglanti = new SqlConnection("Server = LAPTOP-QLN317KI\\SQLEXPRESS ; Initial Catalog = HastaKayitVeteriner ; Integrated Security = True");

        String cinsiyet = "";

        Form1 form1 = new Form1();

        public void HataKontrol()
        {
            baglanti.Open();
            SqlCommand KayitKontrol = new SqlCommand("SELECT * FROM KullaniciBilgileri WHERE telefon_no = @telefon_no",baglanti);
            KayitKontrol.Parameters.AddWithValue("@telefon_no",mskTelNo.Text);
            SqlDataReader dr = KayitKontrol.ExecuteReader();
            if (dr.Read())
            {
                MessageBox.Show("Bu Telefon Numarası Daha Önce Kullanıldı. Lütfen Farklı Bir Telefon Numarası Giriniz","Uyarı",MessageBoxButtons.OK,MessageBoxIcon.Warning);
            }
            baglanti.Close();
        }
        public void KullaniciEkle()
        {
            baglanti.Open();
            SqlCommand kayit = new SqlCommand("INSERT INTO KullaniciBilgileri (adi,soyadi,telefon_no,sifre,is_banned) VALUES(@adi , @soyadi , @telefon_no , @sifre,'F')", baglanti);
            kayit.Parameters.AddWithValue("@adi", txtAdi.Text);
            kayit.Parameters.AddWithValue("@soyadi", txtSoyadi.Text);
            kayit.Parameters.AddWithValue("@telefon_no", mskTelNo.Text);
            kayit.Parameters.AddWithValue("@sifre", txtSifre.Text);
            kayit.ExecuteNonQuery();
            baglanti.Close();
        }
        public void HayvanEkle()
        {
            baglanti.Open();
            SqlCommand kayit2 = new SqlCommand("INSERT INTO HayvanBilgileri (adi,turu,cinsi,cinsiyet) VALUES (@adi,@turu,@cinsi,@cinsiyet)", baglanti);
            kayit2.Parameters.AddWithValue("@adi", txtHayvanAdi.Text);
            kayit2.Parameters.AddWithValue("@turu", txtTuru.Text);
            kayit2.Parameters.AddWithValue("@cinsi", txtCinsi.Text);
            if (rdbDisi.Checked)
            {
                cinsiyet = "D";
            }
            else if (rdbErkek.Checked)
            {
                cinsiyet = "E";
            }
            kayit2.Parameters.AddWithValue("@cinsiyet", cinsiyet);
            kayit2.ExecuteNonQuery();
            baglanti.Close();
        }

        private void btnKayitOl_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            SqlCommand KayitKontrol = new SqlCommand("SELECT * FROM KullaniciBilgileri WHERE telefon_no = @telefon_no", baglanti);
            KayitKontrol.Parameters.AddWithValue("@telefon_no", mskTelNo.Text);
            SqlDataReader dr = KayitKontrol.ExecuteReader();
            if (dr.Read())
            {
                MessageBox.Show("Bu Telefon Numarası Daha Önce Kullanıldı. Lütfen Farklı Bir Telefon Numarası Giriniz", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                KullaniciEkle();
                HayvanEkle();
                MessageBox.Show("Başarıyla Kayıt Oldunuz!", "Tebrikler", MessageBoxButtons.OK, MessageBoxIcon.Information);
                form1.Show();
                this.Hide();
            }
            baglanti.Close();
        
        }

        private void button1_Click(object sender, EventArgs e)
        {
            form1.Show();
            this.Hide();
        }
    }
}
